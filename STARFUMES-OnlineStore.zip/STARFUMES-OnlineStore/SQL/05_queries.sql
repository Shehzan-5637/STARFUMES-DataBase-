SELECT * FROM vw_CustomerOrderHistory1;
SELECT * FROM vw_DailySales1;
SELECT * FROM vw_PendingPayments1;
SELECT * FROM vw_LowStockPerfumes1;

UPDATE Perfumes1
SET stock = 4
WHERE perfume_id = 1;