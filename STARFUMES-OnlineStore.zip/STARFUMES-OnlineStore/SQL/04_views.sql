CREATE VIEW vw_CustomerOrderHistory1 AS
SELECT 
    c.name AS CustomerName,
    o.order_id,
    o.order_date,
    o.status,
    p.perfume_name,
    oi.quantity
FROM Customers1 c
JOIN Orders1 o ON c.customer_id = o.customer_id
JOIN OrderItems1 oi ON o.order_id = oi.order_id
JOIN Perfumes1 p ON oi.perfume_id = p.perfume_id;
GO

CREATE VIEW vw_DailySales1 AS
SELECT 
    o.order_date,
    SUM(pm.amount) AS TotalSales
FROM Orders1 o
JOIN Payments1 pm ON o.order_id = pm.order_id
WHERE pm.payment_status = 'Completed'
GROUP BY o.order_date;
GO

CREATE VIEW vw_PendingPayments1 AS
SELECT 
    o.order_id,
    c.name AS CustomerName,
    pm.amount,
    pm.payment_method,
    pm.payment_status
FROM Orders1 o
JOIN Customers1 c ON o.customer_id = c.customer_id
JOIN Payments1 pm ON o.order_id = pm.order_id
WHERE pm.payment_status = 'Pending';
GO

CREATE VIEW vw_LowStockPerfumes1 AS
SELECT perfume_name, stock
FROM Perfumes1
WHERE stock < 5;
GO