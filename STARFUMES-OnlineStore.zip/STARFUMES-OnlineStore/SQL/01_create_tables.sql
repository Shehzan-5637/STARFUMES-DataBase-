CREATE DATABASE StarFumesDB;
GO
USE StarFumesDB;
GO

CREATE TABLE Customers1 (
    customer_id INT IDENTITY(1,1) PRIMARY KEY,
    name VARCHAR(100),
    address VARCHAR(200)
);

CREATE TABLE Perfumes1 (
    perfume_id INT IDENTITY(1,1) PRIMARY KEY,
    perfume_name VARCHAR(100),
    price DECIMAL(10,2),
    stock INT
);

CREATE TABLE Orders1 (
    order_id INT IDENTITY(1,1) PRIMARY KEY,
    customer_id INT,
    order_date DATE,
    status VARCHAR(50),
    shipping_address VARCHAR(200),
    FOREIGN KEY (customer_id) REFERENCES Customers1(customer_id)
);

CREATE TABLE OrderItems1 (
    item_id INT IDENTITY(1,1) PRIMARY KEY,
    order_id INT,
    perfume_id INT,
    quantity INT,
    FOREIGN KEY (order_id) REFERENCES Orders1(order_id),
    FOREIGN KEY (perfume_id) REFERENCES Perfumes1(perfume_id)
);

CREATE TABLE Payments1 (
    payment_id INT IDENTITY(1,1) PRIMARY KEY,
    order_id INT,
    amount DECIMAL(10,2),
    payment_method VARCHAR(50),
    payment_status VARCHAR(50),
    FOREIGN KEY (order_id) REFERENCES Orders1(order_id)
);
GO