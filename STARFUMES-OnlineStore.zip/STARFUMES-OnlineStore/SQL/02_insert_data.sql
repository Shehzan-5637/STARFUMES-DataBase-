INSERT INTO Customers1 (name, address) VALUES
('Faizan Punjwani','Karachi'),
('Yusra Habib','Islamabad');

INSERT INTO Perfumes1 (perfume_name, price, stock) VALUES
('Sirius Essence',3500,20),
('Vega Bloom',3200,18);

INSERT INTO Orders1 (customer_id, order_date, status, shipping_address) VALUES
(1,'2025-11-01','Confirmed','Karachi'),
(2,'2025-11-02','Pending','Islamabad');

INSERT INTO OrderItems1 (order_id, perfume_id, quantity) VALUES
(1,1,2),(1,2,1);

INSERT INTO Payments1 (order_id, amount, payment_method, payment_status) VALUES
(1,7100,'Bank Transfer','Completed'),
(2,5000,'Cash on Delivery','Pending');