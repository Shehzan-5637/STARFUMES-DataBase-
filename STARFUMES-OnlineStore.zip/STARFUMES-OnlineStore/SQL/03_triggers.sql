CREATE TRIGGER trg_CheckStock
ON OrderItems1
INSTEAD OF INSERT
AS
BEGIN
  IF EXISTS (
    SELECT 1
    FROM inserted i
    JOIN Perfumes1 p ON i.perfume_id = p.perfume_id
    WHERE i.quantity > p.stock
  )
  BEGIN
    RAISERROR ('Insufficient stock available.',16,1);
    RETURN;
  END

  INSERT INTO OrderItems1 (order_id, perfume_id, quantity)
  SELECT order_id, perfume_id, quantity FROM inserted;
END;
GO

CREATE TRIGGER trg_ReduceStock1
ON OrderItems1
AFTER INSERT
AS
BEGIN
  UPDATE p
  SET p.stock = p.stock - i.quantity
  FROM Perfumes1 p
  JOIN inserted i ON p.perfume_id = i.perfume_id;
END;
GO

CREATE TRIGGER trg_UpdateOrderStatus1
ON Payments1
AFTER INSERT
AS
BEGIN
  UPDATE o
  SET o.status = 'Confirmed'
  FROM Orders1 o
  JOIN inserted i ON o.order_id = i.order_id
  WHERE i.payment_status = 'Completed';
END;
GO